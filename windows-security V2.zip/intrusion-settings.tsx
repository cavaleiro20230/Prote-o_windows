"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Shield, Lock, FileWarning } from "lucide-react"
import { X } from "lucide-react"

export default function IntrusionSettings() {
  const [ipsLevel, setIpsLevel] = useState(80)
  const [portScanProtection, setPortScanProtection] = useState(true)
  const [scriptProtection, setScriptProtection] = useState(true)
  const [autoBlock, setAutoBlock] = useState(true)
  const [notifyOnBlock, setNotifyOnBlock] = useState(true)
  const [blockDuration, setBlockDuration] = useState("24")

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Advanced Protection Settings</h2>
        <p className="text-muted-foreground">
          Configure intrusion prevention, port scan protection, and script protection
        </p>
      </div>

      <Tabs defaultValue="intrusion">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="intrusion">Intrusion Protection</TabsTrigger>
          <TabsTrigger value="portscan">Port Scan Protection</TabsTrigger>
          <TabsTrigger value="script">Script Protection</TabsTrigger>
        </TabsList>

        <TabsContent value="intrusion" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Intrusion Prevention System (IPS)</CardTitle>
              <CardDescription>Configure how the system detects and blocks intrusion attempts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="ips-level">Protection Level</Label>
                  <span className="text-sm font-medium">
                    {ipsLevel < 30 ? "Low" : ipsLevel < 70 ? "Medium" : "High"}
                  </span>
                </div>
                <Slider
                  id="ips-level"
                  min={0}
                  max={100}
                  step={1}
                  value={[ipsLevel]}
                  onValueChange={(value) => setIpsLevel(value[0])}
                />
                <p className="text-xs text-muted-foreground">
                  {ipsLevel < 30
                    ? "Low: Only blocks known dangerous attacks with minimal false positives"
                    : ipsLevel < 70
                      ? "Medium: Balanced protection against most threats"
                      : "High: Maximum protection with potential for more false positives"}
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between space-x-2">
                  <div className="flex-1 space-y-1">
                    <Label htmlFor="auto-block">Automatic IP Blocking</Label>
                    <p className="text-xs text-muted-foreground">
                      Automatically block IP addresses that attempt intrusions
                    </p>
                  </div>
                  <Switch id="auto-block" checked={autoBlock} onCheckedChange={setAutoBlock} />
                </div>

                <div className="flex items-center justify-between space-x-2">
                  <div className="flex-1 space-y-1">
                    <Label htmlFor="notify-block">Notification on Block</Label>
                    <p className="text-xs text-muted-foreground">
                      Show notification when an intrusion attempt is blocked
                    </p>
                  </div>
                  <Switch id="notify-block" checked={notifyOnBlock} onCheckedChange={setNotifyOnBlock} />
                </div>

                <div className="space-y-1">
                  <Label htmlFor="block-duration">Block Duration</Label>
                  <Select value={blockDuration} onValueChange={setBlockDuration}>
                    <SelectTrigger id="block-duration">
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 hour</SelectItem>
                      <SelectItem value="6">6 hours</SelectItem>
                      <SelectItem value="24">24 hours</SelectItem>
                      <SelectItem value="168">7 days</SelectItem>
                      <SelectItem value="permanent">Permanent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Protection Features</Label>
                <div className="rounded-md border p-4">
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <Shield className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">Network Traffic Analysis</div>
                        <p className="text-sm text-muted-foreground">
                          Monitors network traffic for suspicious patterns and known attack signatures
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Shield className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">Behavior-based Detection</div>
                        <p className="text-sm text-muted-foreground">
                          Identifies intrusion attempts based on abnormal system behavior
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Shield className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">Exploit Protection</div>
                        <p className="text-sm text-muted-foreground">
                          Prevents exploitation of known vulnerabilities in applications and the operating system
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Save IPS Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="portscan" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Port Scan Protection</CardTitle>
              <CardDescription>Configure protection against port scanning attempts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between space-x-2">
                <div className="flex-1 space-y-1">
                  <Label htmlFor="port-scan-protection">Port Scan Protection</Label>
                  <p className="text-xs text-muted-foreground">Detect and block port scanning attempts</p>
                </div>
                <Switch
                  id="port-scan-protection"
                  checked={portScanProtection}
                  onCheckedChange={setPortScanProtection}
                />
              </div>

              <div className="space-y-2">
                <Label>Protected Ports</Label>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
                  <div className="rounded-md border p-2 text-center">
                    <span className="text-sm font-medium">21 (FTP)</span>
                  </div>
                  <div className="rounded-md border p-2 text-center">
                    <span className="text-sm font-medium">22 (SSH)</span>
                  </div>
                  <div className="rounded-md border p-2 text-center">
                    <span className="text-sm font-medium">23 (Telnet)</span>
                  </div>
                  <div className="rounded-md border p-2 text-center">
                    <span className="text-sm font-medium">25 (SMTP)</span>
                  </div>
                  <div className="rounded-md border p-2 text-center">
                    <span className="text-sm font-medium">80 (HTTP)</span>
                  </div>
                  <div className="rounded-md border p-2 text-center">
                    <span className="text-sm font-medium">443 (HTTPS)</span>
                  </div>
                  <div className="rounded-md border p-2 text-center">
                    <span className="text-sm font-medium">445 (SMB)</span>
                  </div>
                  <div className="rounded-md border p-2 text-center">
                    <span className="text-sm font-medium">3389 (RDP)</span>
                  </div>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <Input placeholder="Add custom port" className="max-w-[200px]" />
                  <Button variant="outline" size="sm">
                    Add
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Protection Features</Label>
                <div className="rounded-md border p-4">
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <Lock className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">Port Scan Detection</div>
                        <p className="text-sm text-muted-foreground">
                          Detects when multiple ports are probed in a short time period
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Lock className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">Stealth Mode</div>
                        <p className="text-sm text-muted-foreground">
                          Makes closed ports appear filtered, hiding information from scanners
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Lock className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">TCP/UDP Protection</div>
                        <p className="text-sm text-muted-foreground">
                          Protects both TCP and UDP ports from scanning attempts
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Save Port Scan Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="script" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Malicious Script Protection</CardTitle>
              <CardDescription>Configure protection against malicious scripts and code execution</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between space-x-2">
                <div className="flex-1 space-y-1">
                  <Label htmlFor="script-protection">Script Protection</Label>
                  <p className="text-xs text-muted-foreground">Detect and block malicious scripts from executing</p>
                </div>
                <Switch id="script-protection" checked={scriptProtection} onCheckedChange={setScriptProtection} />
              </div>

              <div className="space-y-2">
                <Label>Protected Script Types</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="javascript" className="h-4 w-4 rounded border-gray-300" defaultChecked />
                    <Label htmlFor="javascript">JavaScript</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="vbscript" className="h-4 w-4 rounded border-gray-300" defaultChecked />
                    <Label htmlFor="vbscript">VBScript</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="powershell" className="h-4 w-4 rounded border-gray-300" defaultChecked />
                    <Label htmlFor="powershell">PowerShell</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="batch" className="h-4 w-4 rounded border-gray-300" defaultChecked />
                    <Label htmlFor="batch">Batch Files</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="macros" className="h-4 w-4 rounded border-gray-300" defaultChecked />
                    <Label htmlFor="macros">Office Macros</Label>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Protection Features</Label>
                <div className="rounded-md border p-4">
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <FileWarning className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">Behavior Analysis</div>
                        <p className="text-sm text-muted-foreground">
                          Analyzes script behavior for suspicious activities like registry modifications
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <FileWarning className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">Signature Detection</div>
                        <p className="text-sm text-muted-foreground">
                          Identifies known malicious script patterns and code
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <FileWarning className="mt-0.5 h-5 w-5 text-blue-500" />
                      <div className="space-y-1">
                        <div className="font-medium">Execution Control</div>
                        <p className="text-sm text-muted-foreground">
                          Controls which scripts are allowed to run based on source and content
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Exclusions</Label>
                <p className="text-xs text-muted-foreground">
                  Add trusted scripts or applications that should be excluded from scanning
                </p>
                <div className="rounded-md border p-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">C:\Program Files\Trusted App\script.js</span>
                      <Button variant="ghost" size="sm">
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">C:\Users\Admin\Scripts\backup.ps1</span>
                      <Button variant="ghost" size="sm">
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Input placeholder="Add path to exclude" className="flex-1" />
                    <Button variant="outline" size="sm">
                      Add
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Save Script Protection Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Security Alerts</CardTitle>
          <CardDescription>Configure how you receive security alerts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between space-x-2">
              <div className="flex-1 space-y-1">
                <Label>Desktop Notifications</Label>
                <p className="text-xs text-muted-foreground">Show desktop notifications for security events</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between space-x-2">
              <div className="flex-1 space-y-1">
                <Label>Email Alerts</Label>
                <p className="text-xs text-muted-foreground">Send email alerts for critical security events</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between space-x-2">
              <div className="flex-1 space-y-1">
                <Label>Sound Alerts</Label>
                <p className="text-xs text-muted-foreground">Play sound when threats are detected</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full">Save Alert Settings</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

