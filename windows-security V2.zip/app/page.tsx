"use client"

import IntrusionSettings from "../intrusion-settings"

export default function SyntheticV0PageForDeployment() {
  return <IntrusionSettings />
}