"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Shield, AlertCircle, Activity, Zap } from "lucide-react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function RealTimeMonitor() {
  const [activeConnections, setActiveConnections] = useState(12)
  const [blockedAttempts, setBlockedAttempts] = useState(0)
  const [cpuUsage, setCpuUsage] = useState(8)
  const [memoryUsage, setMemoryUsage] = useState(12)
  const [isMonitoring, setIsMonitoring] = useState(true)
  const [logs, setLogs] = useState([
    { id: 1, type: "info", message: "Real-time protection active", timestamp: "12:30:45" },
    { id: 2, type: "info", message: "Port scan protection enabled", timestamp: "12:30:46" },
    { id: 3, type: "info", message: "Script protection active", timestamp: "12:30:47" },
  ])

  // Simulate real-time monitoring
  useEffect(() => {
    if (!isMonitoring) return

    const interval = setInterval(() => {
      // Random chance of detecting an intrusion attempt
      if (Math.random() < 0.2) {
        const attemptTypes = [
          "Port scan attempt detected and blocked",
          "Suspicious connection attempt blocked",
          "Malicious script execution prevented",
          "Potential buffer overflow attempt blocked",
          "Suspicious PowerShell command blocked",
        ]

        const newLog = {
          id: Date.now(),
          type: "warning",
          message: attemptTypes[Math.floor(Math.random() * attemptTypes.length)],
          timestamp: new Date().toLocaleTimeString(),
        }

        setLogs((prevLogs) => [newLog, ...prevLogs].slice(0, 100))
        setBlockedAttempts((prev) => prev + 1)
      }

      // Update network connections
      setActiveConnections((prev) => Math.max(8, Math.min(20, prev + Math.floor(Math.random() * 3) - 1)))

      // Update resource usage
      setCpuUsage((prev) => Math.max(5, Math.min(15, prev + Math.floor(Math.random() * 3) - 1)))
      setMemoryUsage((prev) => Math.max(10, Math.min(18, prev + Math.floor(Math.random() * 3) - 1)))
    }, 3000)

    return () => clearInterval(interval)
  }, [isMonitoring])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Real-Time Security Monitor</h2>
          <p className="text-muted-foreground">Active protection against intrusions and threats</p>
        </div>
        <Button variant={isMonitoring ? "default" : "outline"} onClick={() => setIsMonitoring(!isMonitoring)}>
          {isMonitoring ? "Monitoring Active" : "Start Monitoring"}
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Connections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{activeConnections}</div>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Blocked Attempts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{blockedAttempts}</div>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{cpuUsage}%</div>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{memoryUsage}%</div>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Security Event Log</CardTitle>
          <CardDescription>Real-time monitoring of security events</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Events</TabsTrigger>
              <TabsTrigger value="intrusions">Intrusions</TabsTrigger>
              <TabsTrigger value="portscans">Port Scans</TabsTrigger>
              <TabsTrigger value="scripts">Malicious Scripts</TabsTrigger>
            </TabsList>

            <div className="h-[300px] overflow-auto rounded-md border">
              <div className="space-y-0 p-0">
                {logs.map((log) => (
                  <div key={log.id} className="flex items-start border-b p-3 last:border-0">
                    <div className="mr-2 mt-0.5">
                      {log.type === "warning" ? (
                        <AlertCircle className="h-4 w-4 text-amber-500" />
                      ) : (
                        <Shield className="h-4 w-4 text-blue-500" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p
                          className={`font-medium ${log.type === "warning" ? "text-amber-600 dark:text-amber-400" : ""}`}
                        >
                          {log.message}
                        </p>
                        <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Tabs>
        </CardContent>
        <CardFooter>
          <div className="flex w-full items-center justify-between">
            <Button variant="outline" size="sm">
              Export Logs
            </Button>
            <Badge variant="outline" className="ml-auto">
              {isMonitoring ? "Monitoring Active" : "Monitoring Paused"}
            </Badge>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}

